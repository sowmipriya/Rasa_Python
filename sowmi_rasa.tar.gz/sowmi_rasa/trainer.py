from rasa_nlu.converters import load_data
from rasa_nlu.config import RasaNLUConfig
from rasa_nlu.model import Trainer
from rasa_nlu.model import Metadata, Interpreter

training_data = load_data('/home/bigtapp-user/rasa_nlu/rasa_files/demo-rasa.json')
trainer = Trainer(RasaNLUConfig("/home/bigtapp-user/rasa_nlu/rasa_files/config_spacy.json"))
trainer.train(training_data)
model_directory = trainer.persist('/home/bigtapp-user/rasa_nlu/rasa_files')

interpreter = Interpreter.load(model_directory, RasaNLUConfig("/home/bigtapp-user/rasa_nlu/rasa_files/config_spacy.json"))
#print interpreter.parse(u"The text I want to understand")
