from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from rasa_nlu.model import Metadata, Interpreter
import requests
import json
import logging
from rasa_nlu.converters import load_data
from rasa_nlu.config import RasaNLUConfig
from rasa_nlu.model import Trainer
import numpy as np

from rasa_core import utils
from rasa_core.actions.action import ACTION_LISTEN_NAME
from rasa_core.agent import Agent
from rasa_core.channels.console import ConsoleInputChannel
from rasa_core.domain import TemplateDomain
from rasa_core.interpreter import NaturalLanguageInterpreter
from rasa_core.policies import Policy
from rasa_core.tracker_store import InMemoryTrackerStore

logger = logging.getLogger(__name__)
training_data = load_data('/home/bigtapp-user/rasa_nlu/rasa_files/demo-rasa.json')
trainer = Trainer(RasaNLUConfig("/home/bigtapp-user/rasa_nlu/rasa_files/config_spacy.json"))
trainer.train(training_data)
model_directory = trainer.persist('/home/bigtapp-user/rasa_nlu/rasa_files')
interpreter = Interpreter.load(model_directory, RasaNLUConfig("/home/bigtapp-user/rasa_nlu/rasa_files/config_spacy.json"))


class SimplePolicy(Policy):
    def predict_action_probabilities(self, tracker, domain):
        # type: (DialogueStateTracker, Domain) -> List[float]

        responses = {"greet":3,"goodbye":4,"ask_whoru":5, "ask_where":6, "infoactiv":7, "about":8, "why":9, "career":10, "address_singapore": 11, "address_chennai":12, "name":13, "service":14,  "client":15, "founders":16, "contact":17, "coo":18, "ceo":19, "product":20}

        if tracker.latest_action_name == ACTION_LISTEN_NAME:
            key = tracker.latest_message.intent["name"]
            action = responses[key] if key in responses else 2
	    if tracker.latest_message.text.lower() == 'bigtapp' or tracker.latest_message.text.lower() == 'bigtapp analytics':
		action = 8
	    if 'founder' in tracker.latest_message.text.lower():
		action = 16
	    if 'singapore' in tracker.latest_message.text.lower() and 'address' in tracker.latest_message.text.lower(): 
		action = 11
	    if 'chennai' in tracker.latest_message.text.lower() and 'address' in tracker.latest_message.text.lower():
		action = 12
            return utils.one_hot(action, domain.num_actions)
        else:
            return np.zeros(domain.num_actions)


class HelloInterpreter(NaturalLanguageInterpreter):
    def parse(self, message):
	#r = requests.get('http://localhost:5000/parse?q='+message, auth=('user', 'pass'))
	
	jsonContent = interpreter.parse(message)
	intent = jsonContent['intent']['name']
	
        return {
            "text": message,
            "intent": {"name": intent, "confidence": 1.0},
            "entities": []
        }


def run_hello_world(serve_forever=True):
    default_domain = TemplateDomain.load("examples/default_domain.yml")
    agent = Agent(default_domain,
                  policies=[SimplePolicy()],
                  interpreter=HelloInterpreter(),
                  tracker_store=InMemoryTrackerStore(default_domain))

    if serve_forever:
        # Attach the commandline input to the controller to handle all
        # incoming messages from that channel
        agent.handle_channel(ConsoleInputChannel())

    return agent


if __name__ == '__main__':
    logging.basicConfig(level="DEBUG")
    run_hello_world()
