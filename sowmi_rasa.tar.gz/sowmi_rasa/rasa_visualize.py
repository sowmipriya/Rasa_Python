from rasa_core.training_utils import create_stories_from_file
from rasa_core.training_utils.visualization import visualize_stories
from rasa_nlu.converters import load_data

stories = create_stories_from_file("examples/babi/data/babi_task5_dev_rasa_even_smaller.md")
training_data = load_data("examples/babi/data/babi_dialog_nlu.json")
visualize_stories(stories, "graph.png", training_data=training_data)
